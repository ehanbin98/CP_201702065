package hw06;


public class reverseTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		reverse myRev = new reverse();
		myRev.plz();

	}

}
