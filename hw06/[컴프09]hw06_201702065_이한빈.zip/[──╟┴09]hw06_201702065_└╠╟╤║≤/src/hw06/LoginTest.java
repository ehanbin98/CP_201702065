package hw06;

public class LoginTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login myLogin = new Login ();
		myLogin.setAccount();
		myLogin.checkAccount();
	}

}
