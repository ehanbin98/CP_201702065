
public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee myEm = new Employee();
		myEm.setName("���Ѻ�");
		myEm.setPhone(01030342447);
		myEm.setIncome(500000);
		myEm.print();
	}

}
