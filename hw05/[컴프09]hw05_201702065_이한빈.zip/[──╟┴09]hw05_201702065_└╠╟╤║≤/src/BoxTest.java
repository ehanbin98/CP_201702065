
public class BoxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box myBox = new Box();
		myBox.setWidth(10);
		myBox.setLength(20);
		myBox.setHeight(50);
		myBox.print();
	}

}
