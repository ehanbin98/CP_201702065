
public class dogTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d1,d2;
		d1 = new Dog("������",2);
		d1.print();
		d2 = new Dog("�傋��","�ùٰ�",3);
		d2.print();
		
	}

}
