
public class Shape {
	protected int width, height, a;

	protected int area() {
		return a;
	}

	public void Shape(int w, int h) {
		this.width = w;
		this.height = h;
	}

}
