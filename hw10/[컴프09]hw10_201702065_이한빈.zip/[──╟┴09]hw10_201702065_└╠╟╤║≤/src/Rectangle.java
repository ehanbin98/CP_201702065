public class Rectangle extends Shape {

	public int area() {
		return this.width * this.height;
	}
}